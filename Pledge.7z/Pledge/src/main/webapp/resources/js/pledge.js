
//Submit the form to start the test button
function CountFun()
{   
	var counter=1;
	$.ajax({
		url : "/Pledge/storeCounterValue",
		data : {countVal : counter},
		//dataType : 'html',
		async:false,
		cache:false,
		success : function(result) {
			alert(result);
			$("#pledge").prop("disabled",true);
		},
    });
}
    
