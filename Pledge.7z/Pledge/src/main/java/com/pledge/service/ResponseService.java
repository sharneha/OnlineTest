package com.pledge.service;

public interface ResponseService {


    public void saveUserData(String comments, String emailId);

    public void storeCounterValue(int countVal);

    
    
}
