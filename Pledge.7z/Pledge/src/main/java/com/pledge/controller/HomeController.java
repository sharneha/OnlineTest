package com.pledge.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.pledge.service.ResponseService;

@Controller
public class HomeController {

    @Autowired ResponseService responseService;
    
    @RequestMapping(value="/")
    public ModelAndView home(){
        ModelAndView view = new ModelAndView("pledge");
        return view;
    }
    
    @RequestMapping(value="/storeCounterValue")
    @ResponseBody
    public String storeCounterValue(int countVal){
        responseService.storeCounterValue(countVal);
        return "Thank you for your participation";
    } 
}
