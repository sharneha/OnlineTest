package com.pledge.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.pledge.dao.ResponseDao;
import com.pledge.service.ResponseService;

@Service("service")
@Transactional
public class ResponseServiceImpl implements ResponseService {

    @Autowired ResponseDao responseDao;
    

    public void storeCounterValue(int countVal) {
        responseDao.storeCounterValue(countVal);
        
    }


    public void saveUserData(String comments, String emailId) {
        // TODO Auto-generated method stub
        
    }

}
