package com.pledge.dao;

public interface ResponseDao {

    void storeCounterValue(int countVal);

}
