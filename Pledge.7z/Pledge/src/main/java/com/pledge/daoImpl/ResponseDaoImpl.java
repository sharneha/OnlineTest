package com.pledge.daoImpl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.pledge.dao.ResponseDao;
import com.pledge.modal.Counter;

@Repository("dao")
@Transactional
public class ResponseDaoImpl implements ResponseDao{

    @Autowired SessionFactory sessionFactory;
    
    public void storeCounterValue(int countVal) {
        Counter counter = new Counter();
        counter.setCount(countVal);
        Session session = sessionFactory.getCurrentSession();
        session.saveOrUpdate(counter);
        
    }

}
