-- MySQL dump 10.13  Distrib 5.7.9, for Win64 (x86_64)
--
-- Host: localhost    Database: onlinetest
-- ------------------------------------------------------
-- Server version	5.7.11-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `answer`
--

DROP TABLE IF EXISTS `answer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `answer` (
  `id` int(11) NOT NULL DEFAULT '0',
  `emailId` varchar(45) DEFAULT NULL,
  `questionNumber` varchar(45) DEFAULT NULL,
  `answerValue` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `answer`
--

LOCK TABLES `answer` WRITE;
/*!40000 ALTER TABLE `answer` DISABLE KEYS */;
INSERT INTO `answer` VALUES (610,'nn@timesgroup.com','q0','4'),(611,'nn@timesgroup.com','q1','5'),(612,'nn@timesgroup.com','q2','5'),(613,'nn@timesgroup.com','q3','5'),(614,'nn@timesgroup.com','q4','5'),(615,'nn@timesgroup.com','q5','5'),(616,'nn@timesgroup.com','q6','5'),(617,'nn@timesgroup.com','q7','5'),(618,'nn@timesgroup.com','q8','5'),(619,'nn@timesgroup.com','q9','5'),(620,'nn@timesgroup.com','q10','5'),(621,'nn@timesgroup.com','q11','5'),(622,'nn@timesgroup.com','q12','5'),(623,'nn@timesgroup.com','q13','5'),(624,'nn@timesgroup.com','q14','5'),(625,'nn@timesgroup.com','q15','5'),(626,'nn@timesgroup.com','q16','4'),(627,'nn@timesgroup.com','q17','5'),(628,'nn@timesgroup.com','q18','5'),(629,'nn@timesgroup.com','q19','5'),(630,'nn@timesgroup.com','q20','5'),(631,'nn@timesgroup.com','q21','5'),(632,'nn@timesgroup.com','q22','5'),(633,'nn@timesgroup.com','q23','5'),(634,'nn@timesgroup.com','q24','5'),(635,'nn@timesgroup.com','q25','4'),(636,'nn@timesgroup.com','q26','5'),(637,'nn@timesgroup.com','q27','5'),(638,'nn@timesgroup.com','q28','5'),(639,'nn@timesgroup.com','q29','5'),(640,'nn@timesgroup.com','q30','5'),(641,'nn@timesgroup.com','q31','5'),(642,'nn@timesgroup.com','q32','5'),(643,'nn@timesgroup.com','q33','4'),(644,'nn@timesgroup.com','q34','5'),(645,'nn@timesgroup.com','q35','4'),(646,'nn@timesgroup.com','q36','4'),(647,'nn@timesgroup.com','q37','4'),(648,'nn@timesgroup.com','q38','5'),(649,'nn@timesgroup.com','q39','5'),(650,'nn@timesgroup.com','q40','5'),(651,'nn@timesgroup.com','q41','5'),(652,'nn@timesgroup.com','q42','4');
/*!40000 ALTER TABLE `answer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `commentValue` longtext
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hibernate_sequence`
--

DROP TABLE IF EXISTS `hibernate_sequence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hibernate_sequence` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hibernate_sequence`
--

LOCK TABLES `hibernate_sequence` WRITE;
/*!40000 ALTER TABLE `hibernate_sequence` DISABLE KEYS */;
INSERT INTO `hibernate_sequence` VALUES (654),(654),(654);
/*!40000 ALTER TABLE `hibernate_sequence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `response`
--

DROP TABLE IF EXISTS `response`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `response` (
  `id` int(11) NOT NULL,
  `value` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `response`
--

LOCK TABLES `response` WRITE;
/*!40000 ALTER TABLE `response` DISABLE KEYS */;
INSERT INTO `response` VALUES (1,'True of me'),(2,'Somewhat true of me'),(3,'Neutral'),(4,'Somewhat untrue of me'),(5,'Untrue of me');
/*!40000 ALTER TABLE `response` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `statements`
--

DROP TABLE IF EXISTS `statements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `statements` (
  `id` int(11) NOT NULL,
  `questionNumber` varchar(45) DEFAULT NULL,
  `questionValue` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `statements`
--

LOCK TABLES `statements` WRITE;
/*!40000 ALTER TABLE `statements` DISABLE KEYS */;
INSERT INTO `statements` VALUES (1,'q1','I think of new ways to address challenging problems.'),(2,'q2','I take personal responsibility for all actions and outcomes.'),(3,'q3','I easily connect with a diverse group of people.'),(4,'q4','I act with empathy, showing concern towards all.'),(5,'q5','I keep an open mind to all possibilities.'),(6,'q6','I put to use the diverse strengths of people.'),(7,'q7','I establish processes for monitoring end-results.'),(8,'q8','I treat internal and external people with respect.'),(9,'q9','I constantly think differently.'),(10,'q10','I prevent people from losing time on non-value activities.'),(11,'q11','I Challenges set assumptions.'),(12,'q12','I work to identify process improvement opportunities.'),(13,'q13','I demonstrate learning from all experiences.'),(14,'q14','I gather support for new ideas to be implemented.'),(15,'q15','I am fair and unbiased with all people.'),(16,'q16','I positively accept new initiatives at work.'),(17,'q17','I balance emotional and caring responses with reason, logic, and reality in all decisions.'),(18,'q18','I simplify processes to focus on end-results.'),(19,'q19','I enable resources and authority for people to deliver.'),(20,'q20','I prioritise improvement areas to maximise impact.'),(21,'q21','I actively listen to people with undivided attention.'),(22,'q22','I identify areas worth investing resources in.'),(23,'q23','I persistently work to enhance customer experience.'),(24,'q24','I Hold self and team accountable to meet commitments.'),(25,'q25','I inspire people to out-perform and reach for more.'),(26,'q26','I accept and learn from failures.'),(27,'q27','I bring together people to work on common goals.'),(28,'q28','I stay solution focused, even with unclear or inadequate data.'),(29,'q29','I break silos at work that may be hampering results.'),(30,'q30','I remove bottlenecks for teams to deliver.'),(31,'q31','I champion the cause of internal and external customers.'),(32,'q32','I deliver as per agreed time and cost parameters.'),(33,'q33','I make fast decisions.'),(34,'q34','I strive for a balance between cost and derived value.'),(35,'q35','I seize opportunites, taking calculated risks when needed.'),(36,'q36','I show curiosity to learn new things.'),(37,'q37','I solicit inputs to get things done effectively.'),(38,'q38','I seek inputs from others in problem solving.'),(39,'q39','I ensure people get recognition for their efforts.'),(40,'q40','I support others in difficult times. '),(41,'q41','I remain passionate to get closure, even under pressure.'),(42,'q42','I create opportunities to stretch and learn.'),(43,'q43','I go beyond immediate comfort zone to get things done.');
/*!40000 ALTER TABLE `statements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` int(11) NOT NULL DEFAULT '0',
  `emailId` varchar(45) DEFAULT NULL,
  `comments` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (609,'pp1@timesgroup.com','top 10 elements'),(653,'nn@timesgroup.com','This is not mandatory');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-05-22 20:01:51
