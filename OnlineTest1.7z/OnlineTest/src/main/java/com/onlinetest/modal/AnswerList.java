package com.onlinetest.modal;

import java.util.List;

import javax.persistence.Column;

public class AnswerList {

    private List<Answer> answerlist;

    private String comments;
    
    public List<Answer> getAnswerlist() {
        return answerlist;
    }

    public void setAnswerlist(List<Answer> answerlist) {
        this.answerlist = answerlist;
    }
    
   


    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }
    
   
}
