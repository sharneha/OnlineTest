package com.onlinetest.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mysql.cj.api.jdbc.Statement;
import com.onlinetest.dao.ResponseDao;
import com.onlinetest.modal.Answer;
import com.onlinetest.modal.Response;
import com.onlinetest.modal.User;
import com.onlinetest.service.ResponseService;

@Service("service")
@Transactional
public class ResponseServiceImpl implements ResponseService {

    @Autowired ResponseDao responseDao;
    

    public void saveUserResponse(Answer answer) {
        responseDao.saveUserResponse(answer);
        
    }

    public void saveUserData(String comments, String emailId) {
        User user = new User();
        user.setEmailId(emailId);
        user.setComments(comments);
        responseDao.saveUserData(user);
        
    }

    public void storeCounterValue(int countVal) {
        responseDao.storeCounterValue(countVal);
        
    }

    
    
    
}
