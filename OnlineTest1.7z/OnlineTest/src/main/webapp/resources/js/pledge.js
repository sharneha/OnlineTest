
//Submit the form to start the test button
function CountFun()
{   
	var counter=1;
	$.ajax({
		url : "/OnlineTest/storeCounterValue",
		data : {countVal : counter},
		//dataType : 'html',
		async:false,
		cache:false,
		success : function(result) {
		},
    });
}
    
