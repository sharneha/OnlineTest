package com.onlinetest.service;

import java.util.List;

import com.mysql.cj.api.jdbc.Statement;
import com.onlinetest.modal.Answer;
import com.onlinetest.modal.Response;

public interface ResponseService {

    public void saveUserResponse(Answer answer);

    public void saveUserData(String comments, String emailId);

    
    
}
