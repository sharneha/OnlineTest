package com.onlinetest.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.mysql.cj.api.jdbc.Statement;
import com.onlinetest.modal.Answer;
import com.onlinetest.modal.AnswerList;
import com.onlinetest.modal.Response;
import com.onlinetest.service.ResponseService;

@Controller
public class HomeController {

    @Autowired ResponseService responseService;
    
    @RequestMapping(value="/")
    public ModelAndView home(){
        System.out.println("controller");
        ModelAndView view = new ModelAndView("home");
        return view;
    }
    
       
    @RequestMapping(value="/saveUserResponse")
    public @ResponseBody String saveUserResponse(AnswerList anslist){
        String emailId=null;
        for (Answer answer : anslist.getAnswerlist()) {
            responseService.saveUserResponse(answer);
            emailId= answer.getEmailId();
        }
        responseService.saveUserData(anslist.getComments(), emailId);
        return "success";
    }
    
}
