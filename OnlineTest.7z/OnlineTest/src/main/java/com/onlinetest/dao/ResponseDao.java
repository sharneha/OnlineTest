package com.onlinetest.dao;

import java.util.List;

import com.mysql.cj.api.jdbc.Statement;
import com.onlinetest.modal.Answer;
import com.onlinetest.modal.Response;
import com.onlinetest.modal.User;

public interface ResponseDao {

    void saveUserResponse(Answer answer);

    void saveUserData(User user);

}
