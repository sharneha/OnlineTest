package com.onlinetest.daoimpl;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mysql.cj.api.jdbc.Statement;
import com.onlinetest.dao.ResponseDao;
import com.onlinetest.modal.Answer;
import com.onlinetest.modal.Response;
import com.onlinetest.modal.User;

@Repository("dao")
@Transactional
public class ResponseDaoImpl implements ResponseDao{

    @Autowired SessionFactory sessionFactory;
    
      public void saveUserResponse(Answer answer) {
        Session session = sessionFactory.getCurrentSession();
        session.save(answer);
        
    }

    public void saveUserData(User user) {
        Session session = sessionFactory.getCurrentSession();
        session.save(user);
        
    }

}
